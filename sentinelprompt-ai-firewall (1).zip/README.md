# SentinelPrompt — Enterprise AI Prompt Injection Firewall

An AI-powered security gateway that inspects every prompt before it reaches an
AI model (ChatGPT, Claude, Gemini, DeepSeek, or a local Llama via Ollama),
detecting prompt injection, jailbreak attempts, and data-exfiltration
patterns in real time, and routing each prompt to **Allow / Sanitize / Block**
based on a computed risk score.

This is a working full-stack implementation of the project you described:
FastAPI backend with a real rule-based + risk-scoring detection engine,
JWT auth with role-based access control, threat logging, an analytics
dashboard, and a React/TypeScript frontend.

---

## 1. Project structure

```
ai-prompt-firewall/
├── backend/                 FastAPI application
│   ├── app/
│   │   ├── firewall/         Detection engine (the heart of the project)
│   │   │   ├── rules.py         25+ regex-based detection rules, 8 threat categories
│   │   │   ├── risk_engine.py   Aggregates rule matches into a 0-100 risk score
│   │   │   └── detector.py      Ties rules + scoring together, sanitizes prompts
│   │   ├── routers/           API endpoints (auth, playground, logs, dashboard, admin)
│   │   ├── ai_providers.py    Calls the official API of the selected AI model
│   │   ├── models.py          SQLAlchemy ORM models (User, PromptLog, SecurityPolicy)
│   │   ├── schemas.py         Pydantic request/response schemas
│   │   ├── auth.py            JWT + password hashing + RBAC dependencies
│   │   ├── config.py          Settings loaded from .env
│   │   └── main.py            App entrypoint, seeds a default admin on first run
│   ├── requirements.txt
│   └── .env.example
└── frontend/                 React + TypeScript + Vite + Tailwind
    └── src/
        ├── pages/             Login, Register, Playground, Dashboard, Logs, Admin
        ├── components/        Sidebar, RiskGauge, ProtectedRoute, AuthBrandPanel
        └── lib/                api.ts (fetch wrapper), auth.tsx (auth context)
```

## 2. How the firewall actually works

1. A user submits a prompt in the **AI Playground**, choosing a target model.
2. The backend's `scan_prompt()` runs the prompt against every rule in
   `firewall/rules.py`. Each rule is a compiled regex tied to a threat
   category (instruction override, system-prompt leak, role manipulation /
   jailbreak, policy bypass, data exfiltration, encoding obfuscation,
   delimiter injection, multi-turn escalation).
3. `risk_engine.py` combines the matched rules' weights into a single 0–100
   score, using diminishing returns *within* a category (so one repeated
   keyword doesn't automatically max out the score) while still scoring
   genuinely multi-vector attacks much higher.
4. The score is compared against two configurable thresholds
   (`risk_threshold_sanitize`, `risk_threshold_block` — editable live from
   the Admin panel):
   - **below sanitize threshold → Allowed**, forwarded as-is
   - **between thresholds → Sanitized**, offending spans are redacted before
     forwarding
   - **at/above block threshold → Blocked**, never reaches the AI provider
5. Every scan (allowed, sanitized, or blocked) is written to the
   `prompt_logs` table with its risk score and matched rules, powering the
   **Threat Logs** and **Dashboard** pages.

## 3. Running it locally

### Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env: add at least one AI provider API key if you want real AI responses,
# otherwise the firewall logic still works end-to-end and will just report
# that the provider key is missing.
uvicorn app.main:app --reload --port 8000
```

The first time it starts, it creates the SQLite database and seeds a default
admin account (from `.env`: `DEFAULT_ADMIN_EMAIL` / `DEFAULT_ADMIN_PASSWORD`,
default `admin@enterprise-corp.com` / `ChangeMe123!` — change this before any
real deployment). API docs are available at `http://localhost:8000/docs`.

To use Postgres instead of SQLite, set `DATABASE_URL` in `.env` to something
like `postgresql://user:pass@localhost:5432/ai_firewall` (the `psycopg2-binary`
driver is already in requirements.txt).

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. The Vite dev server proxies `/api/*` requests
to `http://127.0.0.1:8000`, so both servers need to be running together.

To build for production: `npm run build` (outputs to `frontend/dist`, servable
by any static host or through Nginx in front of the FastAPI backend).

## 4. Default login

| | |
|---|---|
| Email | `admin@enterprise-corp.com` |
| Password | `ChangeMe123!` |
| Role | Administrator |

The **first** account you register through the UI (if you register before
ever starting the backend, i.e. before the seed runs) also becomes an admin
automatically; every account after that is a regular member. Admins can
promote/demote other users from the Administration page.

## 5. Configuring AI providers

Real API calls require keys in `backend/.env`:

```
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=...
DEEPSEEK_API_KEY=...
OLLAMA_BASE_URL=http://localhost:11434   # for a locally running Ollama + Llama
```

Without a key configured, the firewall still scans, scores, and logs every
prompt correctly — it just reports that the provider call couldn't be made,
rather than crashing. This lets you demo and test the entire security layer
without needing any paid API access.

## 6. Extending the detection engine

All detection logic lives in `backend/app/firewall/rules.py` as a flat list
of `Rule` objects (regex pattern, category, weight, description) — add a new
entry to extend coverage without touching any other code. `risk_engine.py`
and `detector.py` never need to change when rules are added or removed.

## 7. Roadmap ideas (see project description)

- Swap/augment the regex rules with an ML/embedding-based classifier
- Browser extension that routes prompts through this firewall on any AI site
- SIEM/webhook integration for the Threat Logging module
- Image and voice-prompt scanning
