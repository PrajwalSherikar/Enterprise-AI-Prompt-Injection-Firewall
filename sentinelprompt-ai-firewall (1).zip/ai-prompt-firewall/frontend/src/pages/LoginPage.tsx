import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth";
import { ApiError } from "../lib/api";
import AuthBrandPanel from "../components/AuthBrandPanel";

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await login(email, password);
      navigate("/playground");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen bg-ink-950">
      <AuthBrandPanel />
      <div className="flex w-full flex-col justify-center px-8 py-12 sm:px-16 lg:w-1/2">
        <div className="mx-auto w-full max-w-sm">
          <h2 className="font-display text-2xl font-semibold text-ink-100">Sign in</h2>
          <p className="mt-1 text-sm text-ink-400">Access the AI Playground and security dashboard.</p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-ink-200">Work email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="w-full rounded-lg border border-ink-700 bg-ink-900 px-3.5 py-2.5 text-sm text-ink-100 placeholder-ink-500 outline-none transition-colors focus:border-signal-500"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-ink-200">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-lg border border-ink-700 bg-ink-900 px-3.5 py-2.5 text-sm text-ink-100 placeholder-ink-500 outline-none transition-colors focus:border-signal-500"
              />
            </div>

            {error && (
              <div className="rounded-lg border border-danger-500/30 bg-danger-500/10 px-3.5 py-2.5 text-sm text-danger-400">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded-lg bg-signal-500 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-signal-600 disabled:opacity-60"
            >
              {submitting ? "Signing in…" : "Sign in"}
            </button>
          </form>

          <p className="mt-6 text-sm text-ink-400">
            New to SentinelPrompt?{" "}
            <Link to="/register" className="font-medium text-signal-400 hover:text-signal-300">
              Create an account
            </Link>
          </p>

          <div className="mt-8 rounded-lg border border-ink-700 bg-ink-900/60 px-4 py-3 text-xs text-ink-400">
            Default admin (first run): <span className="font-mono text-ink-300">admin@enterprise-corp.com</span> /{" "}
            <span className="font-mono text-ink-300">ChangeMe123!</span>
          </div>
        </div>
      </div>
    </div>
  );
}
