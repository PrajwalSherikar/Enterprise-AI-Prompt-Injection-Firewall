import { useEffect, useState } from "react";
import { api, ApiError, type UserOut, type PolicyOut } from "../lib/api";

export default function AdminPage() {
  const [users, setUsers] = useState<UserOut[] | null>(null);
  const [policies, setPolicies] = useState<PolicyOut[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [savingKey, setSavingKey] = useState<string | null>(null);

  function refresh() {
    api.get<UserOut[]>("/admin/users").then(setUsers).catch(() => setError("Could not load users."));
    api.get<PolicyOut[]>("/admin/policies").then(setPolicies).catch(() => setError("Could not load policies."));
  }

  useEffect(refresh, []);

  async function toggleActive(id: string) {
    try {
      await api.patch(`/admin/users/${id}/toggle-active`);
      refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not update user.");
    }
  }

  async function changeRole(id: string, role: "admin" | "user") {
    try {
      await api.patch(`/admin/users/${id}/role?role=${role}`);
      refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not update role.");
    }
  }

  async function savePolicy(key: string, value: string) {
    setSavingKey(key);
    try {
      await api.put("/admin/policies", { key, value });
      refresh();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not update policy.");
    } finally {
      setSavingKey(null);
    }
  }

  return (
    <div className="mx-auto max-w-5xl px-8 py-10">
      <header className="mb-8">
        <h1 className="font-display text-2xl font-semibold text-ink-100">Administration</h1>
        <p className="mt-1 text-sm text-ink-400">Manage user access and tune the firewall's risk thresholds.</p>
      </header>

      {error && (
        <div className="mb-6 rounded-lg border border-danger-500/30 bg-danger-500/10 px-4 py-3 text-sm text-danger-400">{error}</div>
      )}

      <section className="mb-10">
        <h2 className="mb-3 text-sm font-semibold text-ink-200">Risk thresholds</h2>
        <p className="mb-4 text-xs text-ink-500">
          Scores are on a 0–100 scale. A prompt below the sanitize threshold is allowed as-is; between the two
          thresholds it is sanitized (offending spans redacted) before being forwarded; at or above the block
          threshold it never reaches the AI model.
        </p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {policies?.map((p) => (
            <PolicyEditor key={p.key} policy={p} saving={savingKey === p.key} onSave={savePolicy} />
          ))}
          {!policies && <div className="text-sm text-ink-400">Loading policies…</div>}
        </div>
      </section>

      <section>
        <h2 className="mb-3 text-sm font-semibold text-ink-200">Users</h2>
        <div className="overflow-hidden rounded-xl border border-ink-700 bg-ink-900">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-ink-700 text-xs uppercase tracking-wide text-ink-500">
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Email</th>
                <th className="px-4 py-3 font-medium">Role</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users?.map((u) => (
                <tr key={u.id} className="border-b border-ink-700 last:border-0">
                  <td className="px-4 py-3 text-ink-200">{u.name}</td>
                  <td className="px-4 py-3 text-ink-400">{u.email}</td>
                  <td className="px-4 py-3">
                    <select
                      value={u.role}
                      onChange={(e) => changeRole(u.id, e.target.value as "admin" | "user")}
                      className="rounded-md border border-ink-700 bg-ink-800 px-2 py-1 text-xs text-ink-200"
                    >
                      <option value="user">User</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs font-semibold ${
                        u.is_active ? "bg-safe-500/15 text-safe-400" : "bg-danger-500/15 text-danger-400"
                      }`}
                    >
                      {u.is_active ? "Active" : "Disabled"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => toggleActive(u.id)}
                      className="rounded-md border border-ink-700 px-2.5 py-1 text-xs text-ink-300 hover:border-ink-600 hover:text-ink-100"
                    >
                      {u.is_active ? "Disable" : "Enable"}
                    </button>
                  </td>
                </tr>
              ))}
              {!users && (
                <tr>
                  <td className="px-4 py-6 text-sm text-ink-400" colSpan={5}>
                    Loading users…
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

function PolicyEditor({
  policy,
  saving,
  onSave,
}: {
  policy: PolicyOut;
  saving: boolean;
  onSave: (key: string, value: string) => void;
}) {
  const [value, setValue] = useState(policy.value);
  const dirty = value !== policy.value;

  return (
    <div className="rounded-xl border border-ink-700 bg-ink-900 p-4">
      <div className="font-mono text-xs text-signal-400">{policy.key}</div>
      <div className="mt-1 mb-3 text-xs text-ink-400">{policy.description}</div>
      <div className="flex items-center gap-2">
        <input
          type="number"
          min={0}
          max={100}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          className="w-24 rounded-md border border-ink-700 bg-ink-800 px-2.5 py-1.5 font-mono text-sm text-ink-100 outline-none focus:border-signal-500"
        />
        <button
          onClick={() => onSave(policy.key, value)}
          disabled={!dirty || saving}
          className="rounded-md bg-signal-500 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-signal-600 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {saving ? "Saving…" : "Save"}
        </button>
      </div>
    </div>
  );
}
