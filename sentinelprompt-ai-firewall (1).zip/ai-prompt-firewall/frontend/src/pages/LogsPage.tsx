import { Fragment, useEffect, useState } from "react";
import { api, type PromptLogOut } from "../lib/api";
import { verdictColor } from "../components/RiskGauge";

const FILTERS = [
  { id: "", label: "All" },
  { id: "allowed", label: "Allowed" },
  { id: "sanitized", label: "Sanitized" },
  { id: "blocked", label: "Blocked" },
];

function truncate(text: string, n: number) {
  return text.length > n ? text.slice(0, n) + "…" : text;
}

export default function LogsPage() {
  const [logs, setLogs] = useState<PromptLogOut[] | null>(null);
  const [filter, setFilter] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    setLogs(null);
    const query = filter ? `?verdict=${filter}` : "";
    api
      .get<PromptLogOut[]>(`/logs/${query}`)
      .then(setLogs)
      .catch(() => setError("Could not load threat logs."));
  }, [filter]);

  return (
    <div className="mx-auto max-w-6xl px-8 py-10">
      <header className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink-100">Threat Logs</h1>
        <p className="mt-1 text-sm text-ink-400">Every prompt scanned by the firewall, with its verdict and matched rules.</p>
      </header>

      <div className="mb-4 flex gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors ${
              filter === f.id
                ? "border-signal-500 bg-signal-500/10 text-signal-400"
                : "border-ink-700 text-ink-300 hover:border-ink-600"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {error && (
        <div className="rounded-lg border border-danger-500/30 bg-danger-500/10 px-4 py-3 text-sm text-danger-400">{error}</div>
      )}

      {!error && logs === null && <div className="text-sm text-ink-400">Loading logs…</div>}

      {!error && logs !== null && logs.length === 0 && (
        <div className="rounded-xl border border-ink-700 bg-ink-900 p-10 text-center text-sm text-ink-500">
          No log entries match this filter yet.
        </div>
      )}

      {!error && logs !== null && logs.length > 0 && (
        <div className="overflow-hidden rounded-xl border border-ink-700 bg-ink-900">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-ink-700 text-xs uppercase tracking-wide text-ink-500">
                <th className="px-4 py-3 font-medium">Time</th>
                <th className="px-4 py-3 font-medium">Model</th>
                <th className="px-4 py-3 font-medium">Prompt</th>
                <th className="px-4 py-3 font-medium">Risk</th>
                <th className="px-4 py-3 font-medium">Verdict</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log) => {
                const rules = log.matched_rules ? (JSON.parse(log.matched_rules) as { rule_id: string; description: string }[]) : [];
                const isOpen = expanded === log.id;
                return (
                  <Fragment key={log.id}>
                    <tr
                      onClick={() => setExpanded(isOpen ? null : log.id)}
                      className="cursor-pointer border-b border-ink-700 last:border-0 hover:bg-ink-800/50"
                    >
                      <td className="whitespace-nowrap px-4 py-3 font-mono text-xs text-ink-400">
                        {new Date(log.created_at).toLocaleString()}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-ink-300">{log.ai_model}</td>
                      <td className="px-4 py-3 text-ink-200">{truncate(log.prompt_text, 70)}</td>
                      <td className="px-4 py-3 font-mono text-xs font-semibold" style={{ color: verdictColor(log.verdict) }}>
                        {log.risk_score.toFixed(0)}
                      </td>
                      <td className="px-4 py-3">
                        <span
                          className="rounded-full px-2 py-0.5 text-xs font-semibold"
                          style={{
                            color: verdictColor(log.verdict),
                            backgroundColor: "color-mix(in srgb, " + verdictColor(log.verdict) + " 15%, transparent)",
                          }}
                        >
                          {log.verdict}
                        </span>
                      </td>
                    </tr>
                    {isOpen && (
                      <tr className="border-b border-ink-700 bg-ink-800/30 last:border-0">
                        <td colSpan={5} className="px-4 py-4">
                          <div className="mb-2 text-xs font-medium uppercase tracking-wide text-ink-500">Full prompt</div>
                          <div className="mb-3 rounded-lg border border-ink-700 bg-ink-900 px-3 py-2 font-mono text-xs text-ink-300 whitespace-pre-wrap">
                            {log.prompt_text}
                          </div>
                          {rules.length > 0 && (
                            <>
                              <div className="mb-2 text-xs font-medium uppercase tracking-wide text-ink-500">Matched rules</div>
                              <div className="flex flex-wrap gap-2">
                                {rules.map((r) => (
                                  <span
                                    key={r.rule_id}
                                    className="rounded-md border border-ink-700 bg-ink-900 px-2 py-1 font-mono text-xs text-ink-300"
                                    title={r.description}
                                  >
                                    {r.rule_id}
                                  </span>
                                ))}
                              </div>
                            </>
                          )}
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
