import { useEffect, useState } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts";
import { api, type DashboardStats } from "../lib/api";

const VERDICT_COLORS: Record<string, string> = {
  allowed: "#2dd4bf",
  sanitized: "#f5b942",
  blocked: "#f05252",
};

function StatCard({ label, value, accent }: { label: string; value: string | number; accent?: string }) {
  return (
    <div className="rounded-xl border border-ink-700 bg-ink-900 p-5">
      <div className="text-xs font-medium uppercase tracking-wide text-ink-500">{label}</div>
      <div className="mt-2 font-mono text-3xl font-semibold" style={{ color: accent ?? "#e6e7f2" }}>
        {value}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api
      .get<DashboardStats>("/dashboard/stats")
      .then(setStats)
      .catch(() => setError("Could not load dashboard data."));
  }, []);

  if (error) {
    return (
      <div className="mx-auto max-w-6xl px-8 py-10">
        <div className="rounded-lg border border-danger-500/30 bg-danger-500/10 px-4 py-3 text-sm text-danger-400">{error}</div>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="mx-auto max-w-6xl px-8 py-10 text-sm text-ink-400">Loading dashboard…</div>
    );
  }

  const pieData = stats.verdict_breakdown.filter((v) => v.count > 0);

  return (
    <div className="mx-auto max-w-6xl px-8 py-10">
      <header className="mb-8">
        <h1 className="font-display text-2xl font-semibold text-ink-100">Security Dashboard</h1>
        <p className="mt-1 text-sm text-ink-400">Real-time visibility into prompt traffic and blocked threats.</p>
      </header>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard label="Total prompts" value={stats.total_prompts} />
        <StatCard label="Allowed" value={stats.total_allowed} accent="#2dd4bf" />
        <StatCard label="Sanitized" value={stats.total_sanitized} accent="#f5b942" />
        <StatCard label="Blocked" value={stats.total_blocked} accent="#f05252" />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="rounded-xl border border-ink-700 bg-ink-900 p-5 lg:col-span-2">
          <div className="mb-4 text-sm font-medium text-ink-200">Prompt volume over time</div>
          {stats.prompts_over_time.length === 0 ? (
            <EmptyState text="No prompt activity yet. Try a scan in the AI Playground." />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={stats.prompts_over_time}>
                <defs>
                  <linearGradient id="allowedGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#232536" />
                <XAxis dataKey="date" tick={{ fill: "#6b6f92", fontSize: 11 }} axisLine={{ stroke: "#232536" }} tickLine={false} />
                <YAxis tick={{ fill: "#6b6f92", fontSize: 11 }} axisLine={{ stroke: "#232536" }} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ background: "#191b28", border: "1px solid #232536", borderRadius: 8, fontSize: 12 }}
                  labelStyle={{ color: "#c2c4dc" }}
                />
                <Area type="monotone" dataKey="allowed" stackId="1" stroke="#2dd4bf" fill="url(#allowedGrad)" />
                <Area type="monotone" dataKey="sanitized" stackId="1" stroke="#f5b942" fill="#f5b94222" />
                <Area type="monotone" dataKey="blocked" stackId="1" stroke="#f05252" fill="#f0525222" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="rounded-xl border border-ink-700 bg-ink-900 p-5">
          <div className="mb-4 text-sm font-medium text-ink-200">Verdict breakdown</div>
          {pieData.length === 0 ? (
            <EmptyState text="No verdicts recorded yet." />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} dataKey="count" nameKey="verdict" innerRadius={55} outerRadius={85} paddingAngle={3}>
                  {pieData.map((entry) => (
                    <Cell key={entry.verdict} fill={VERDICT_COLORS[entry.verdict]} stroke="none" />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: "#191b28", border: "1px solid #232536", borderRadius: 8, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
          <div className="mt-2 flex justify-center gap-4">
            {pieData.map((v) => (
              <div key={v.verdict} className="flex items-center gap-1.5 text-xs text-ink-400">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: VERDICT_COLORS[v.verdict] }} />
                {v.verdict}
              </div>
            ))}
          </div>
          <div className="mt-4 border-t border-ink-700 pt-3 text-center">
            <div className="font-mono text-xl font-semibold text-danger-400">{stats.block_rate}%</div>
            <div className="text-xs text-ink-500">block rate</div>
          </div>
        </div>
      </div>

      <div className="mt-6 rounded-xl border border-ink-700 bg-ink-900 p-5">
        <div className="mb-4 text-sm font-medium text-ink-200">Most triggered detection rules</div>
        {stats.top_rules.length === 0 ? (
          <EmptyState text="No rules have fired yet." />
        ) : (
          <ResponsiveContainer width="100%" height={Math.max(160, stats.top_rules.length * 40)}>
            <BarChart data={stats.top_rules} layout="vertical" margin={{ left: 24 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#232536" horizontal={false} />
              <XAxis type="number" tick={{ fill: "#6b6f92", fontSize: 11 }} axisLine={{ stroke: "#232536" }} tickLine={false} allowDecimals={false} />
              <YAxis
                type="category"
                dataKey="rule"
                tick={{ fill: "#9295b5", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                width={260}
              />
              <Tooltip contentStyle={{ background: "#191b28", border: "1px solid #232536", borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="count" fill="#7c6ff0" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return <div className="flex h-40 items-center justify-center text-sm text-ink-500">{text}</div>;
}
