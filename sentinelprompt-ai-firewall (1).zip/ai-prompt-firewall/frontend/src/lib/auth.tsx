import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { api, setToken, type UserOut, type AuthResponse } from "./api";

interface AuthContextValue {
  user: UserOut | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserOut | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("sentinel_token");
    if (!token) {
      setLoading(false);
      return;
    }
    api
      .get<UserOut>("/auth/me")
      .then(setUser)
      .catch(() => setToken(null))
      .finally(() => setLoading(false));
  }, []);

  async function login(email: string, password: string) {
    const resp = await api.post<AuthResponse>("/auth/login", { email, password });
    setToken(resp.access_token);
    setUser(resp.user);
  }

  async function register(name: string, email: string, password: string) {
    const resp = await api.post<AuthResponse>("/auth/register", { name, email, password });
    setToken(resp.access_token);
    setUser(resp.user);
  }

  function logout() {
    setToken(null);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
