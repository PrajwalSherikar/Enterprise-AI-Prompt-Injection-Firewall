const API_BASE = "/api";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function getToken(): string | null {
  return localStorage.getItem("sentinel_token");
}

export function setToken(token: string | null) {
  if (token) localStorage.setItem("sentinel_token", token);
  else localStorage.removeItem("sentinel_token");
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string> | undefined),
  };
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });

  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail);
    } catch {
      /* no body */
    }
    throw new ApiError(res.status, detail || "Request failed");
  }

  if (res.status === 204) return undefined as T;
  return res.json();
}

export const api = {
  get: <T>(path: string) => request<T>(path, { method: "GET" }),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined }),
  put: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PUT", body: body ? JSON.stringify(body) : undefined }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "PATCH", body: body ? JSON.stringify(body) : undefined }),
};

// ---------- Types shared with backend schemas ----------

export interface UserOut {
  id: string;
  name: string;
  email: string;
  role: "admin" | "user";
  is_active: boolean;
  created_at: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: UserOut;
}

export interface MatchedRule {
  rule_id: string;
  category: string;
  description: string;
  weight: number;
}

export interface PromptResponse {
  verdict: "allowed" | "sanitized" | "blocked";
  risk_score: number;
  matched_rules: MatchedRule[];
  ai_response: string | null;
  message: string;
}

export interface PromptLogOut {
  id: string;
  user_id: string;
  ai_model: string;
  prompt_text: string;
  verdict: "allowed" | "sanitized" | "blocked";
  risk_score: number;
  matched_rules: string | null;
  created_at: string;
}

export interface DashboardStats {
  total_prompts: number;
  total_blocked: number;
  total_sanitized: number;
  total_allowed: number;
  block_rate: number;
  top_rules: { rule: string; count: number }[];
  prompts_over_time: { date: string; allowed: number; sanitized: number; blocked: number }[];
  verdict_breakdown: { verdict: string; count: number }[];
}

export interface PolicyOut {
  key: string;
  value: string;
  description: string | null;
}
