interface RiskGaugeProps {
  score: number;
  size?: number;
  strokeWidth?: number;
  showLabel?: boolean;
}

function colorForScore(score: number): string {
  if (score >= 70) return "var(--color-danger-500)";
  if (score >= 40) return "var(--color-warn-500)";
  return "var(--color-safe-500)";
}

export function verdictColor(verdict: string): string {
  if (verdict === "blocked") return "var(--color-danger-500)";
  if (verdict === "sanitized") return "var(--color-warn-500)";
  return "var(--color-safe-500)";
}

export default function RiskGauge({ score, size = 96, strokeWidth = 9, showLabel = true }: RiskGaugeProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = Math.PI * radius; // half circle
  const clamped = Math.max(0, Math.min(100, score));
  const offset = circumference - (clamped / 100) * circumference;
  const color = colorForScore(clamped);

  return (
    <div className="flex flex-col items-center" style={{ width: size }}>
      <svg width={size} height={size / 2 + strokeWidth / 2} viewBox={`0 0 ${size} ${size / 2 + strokeWidth / 2}`}>
        <path
          d={`M ${strokeWidth / 2} ${size / 2} A ${radius} ${radius} 0 0 1 ${size - strokeWidth / 2} ${size / 2}`}
          fill="none"
          stroke="var(--color-ink-700)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />
        <path
          d={`M ${strokeWidth / 2} ${size / 2} A ${radius} ${radius} 0 0 1 ${size - strokeWidth / 2} ${size / 2}`}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.6s ease, stroke 0.3s ease" }}
        />
      </svg>
      {showLabel && (
        <div className="-mt-5 font-mono font-semibold text-lg" style={{ color }}>
          {clamped.toFixed(0)}
        </div>
      )}
    </div>
  );
}
