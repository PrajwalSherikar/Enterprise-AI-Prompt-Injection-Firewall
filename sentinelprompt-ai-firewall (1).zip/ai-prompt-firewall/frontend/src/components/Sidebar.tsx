import { NavLink } from "react-router-dom";
import { useAuth } from "../lib/auth";

const navItems = [
  { to: "/playground", label: "AI Playground", icon: PlaygroundIcon },
  { to: "/dashboard", label: "Dashboard", icon: DashboardIcon },
  { to: "/logs", label: "Threat Logs", icon: LogsIcon },
];

export default function Sidebar() {
  const { user, logout } = useAuth();

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-ink-700 bg-ink-900/60 backdrop-blur">
      <div className="flex items-center gap-2 px-6 py-6">
        <ShieldMark />
        <div>
          <div className="font-display text-lg font-semibold leading-tight text-ink-100">SentinelPrompt</div>
          <div className="text-xs text-ink-400">AI Prompt Firewall</div>
        </div>
      </div>

      <nav className="flex-1 space-y-1 px-3">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive
                  ? "bg-signal-500/15 text-signal-400"
                  : "text-ink-300 hover:bg-ink-800 hover:text-ink-100"
              }`
            }
          >
            <item.icon />
            {item.label}
          </NavLink>
        ))}
        {user?.role === "admin" && (
          <NavLink
            to="/admin"
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                isActive
                  ? "bg-signal-500/15 text-signal-400"
                  : "text-ink-300 hover:bg-ink-800 hover:text-ink-100"
              }`
            }
          >
            <AdminIcon />
            Administration
          </NavLink>
        )}
      </nav>

      <div className="border-t border-ink-700 p-4">
        <div className="mb-3 flex items-center gap-3 rounded-lg bg-ink-800 px-3 py-2.5">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-signal-500/20 font-display text-sm font-semibold text-signal-400">
            {user?.name?.[0]?.toUpperCase() ?? "?"}
          </div>
          <div className="min-w-0">
            <div className="truncate text-sm font-medium text-ink-100">{user?.name}</div>
            <div className="truncate text-xs text-ink-400">{user?.role === "admin" ? "Administrator" : "Member"}</div>
          </div>
        </div>
        <button
          onClick={logout}
          className="w-full rounded-lg border border-ink-700 px-3 py-2 text-sm font-medium text-ink-300 transition-colors hover:border-danger-500/50 hover:text-danger-400"
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}

function ShieldMark() {
  return (
    <svg width="30" height="30" viewBox="0 0 30 30" fill="none">
      <path
        d="M15 2 L26 6.5 V14.5 C26 21.5 21.2 26.6 15 28.5 C8.8 26.6 4 21.5 4 14.5 V6.5 Z"
        fill="url(#g1)"
      />
      <path d="M10.5 15 L13.5 18 L19.5 11.5" stroke="#0b0c14" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <defs>
        <linearGradient id="g1" x1="4" y1="2" x2="26" y2="28.5" gradientUnits="userSpaceOnUse">
          <stop stopColor="#7c6ff0" />
          <stop offset="1" stopColor="#2dd4bf" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function PlaygroundIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M4 4h16v12H8l-4 4V4Z" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8 9h8M8 12h5" strokeLinecap="round" />
    </svg>
  );
}
function DashboardIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <rect x="3" y="3" width="8" height="8" rx="1.5" />
      <rect x="13" y="3" width="8" height="5" rx="1.5" />
      <rect x="13" y="10" width="8" height="11" rx="1.5" />
      <rect x="3" y="13" width="8" height="8" rx="1.5" />
    </svg>
  );
}
function LogsIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M4 4h16v16H4z" strokeLinecap="round" strokeLinejoin="round" opacity="0" />
      <path d="M6 6h12M6 11h12M6 16h8" strokeLinecap="round" />
      <circle cx="3.2" cy="6" r="0.6" fill="currentColor" stroke="none" />
      <circle cx="3.2" cy="11" r="0.6" fill="currentColor" stroke="none" />
      <circle cx="3.2" cy="16" r="0.6" fill="currentColor" stroke="none" />
    </svg>
  );
}
function AdminIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <circle cx="12" cy="8" r="3.2" />
      <path d="M5 20c0-3.6 3.1-6.4 7-6.4s7 2.8 7 6.4" strokeLinecap="round" />
    </svg>
  );
}
