export default function AuthBrandPanel() {
  return (
    <div className="relative hidden w-1/2 flex-col justify-between overflow-hidden bg-ink-900 p-12 lg:flex">
      <div
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          backgroundImage:
            "radial-gradient(circle at 20% 20%, rgba(124,111,240,0.25), transparent 45%), radial-gradient(circle at 80% 70%, rgba(45,212,191,0.18), transparent 40%)",
        }}
      />
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.035) 1px, transparent 1px)",
          backgroundSize: "42px 42px",
        }}
      />

      <div className="relative flex items-center gap-2.5">
        <svg width="34" height="34" viewBox="0 0 30 30" fill="none">
          <path d="M15 2 L26 6.5 V14.5 C26 21.5 21.2 26.6 15 28.5 C8.8 26.6 4 21.5 4 14.5 V6.5 Z" fill="url(#gA)" />
          <path d="M10.5 15 L13.5 18 L19.5 11.5" stroke="#0b0c14" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <defs>
            <linearGradient id="gA" x1="4" y1="2" x2="26" y2="28.5" gradientUnits="userSpaceOnUse">
              <stop stopColor="#7c6ff0" />
              <stop offset="1" stopColor="#2dd4bf" />
            </linearGradient>
          </defs>
        </svg>
        <span className="font-display text-xl font-semibold text-ink-100">SentinelPrompt</span>
      </div>

      <div className="relative max-w-md">
        <h1 className="font-display text-4xl font-semibold leading-[1.15] text-ink-100">
          Every prompt inspected.<br />Nothing leaks through.
        </h1>
        <p className="mt-4 text-ink-300">
          A security gateway that sits between your people and every AI model —
          scanning for prompt injection, jailbreaks, and data exfiltration in real time.
        </p>

        <div className="mt-8 flex gap-3">
          <div className="rounded-lg border border-ink-700 bg-ink-800/60 px-4 py-3">
            <div className="font-mono text-lg font-semibold text-safe-400">Allow</div>
            <div className="text-xs text-ink-400">Clean prompts pass straight through</div>
          </div>
          <div className="rounded-lg border border-ink-700 bg-ink-800/60 px-4 py-3">
            <div className="font-mono text-lg font-semibold text-warn-400">Sanitize</div>
            <div className="text-xs text-ink-400">Risky spans redacted, then forwarded</div>
          </div>
          <div className="rounded-lg border border-ink-700 bg-ink-800/60 px-4 py-3">
            <div className="font-mono text-lg font-semibold text-danger-400">Block</div>
            <div className="text-xs text-ink-400">High-risk prompts never reach the model</div>
          </div>
        </div>
      </div>

      <div className="relative text-xs text-ink-500">
        Rule-based detection · Risk scoring · Threat logging · Multi-model support
      </div>
    </div>
  );
}
