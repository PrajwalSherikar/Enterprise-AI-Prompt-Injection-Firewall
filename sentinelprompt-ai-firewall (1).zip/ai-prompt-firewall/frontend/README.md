# SentinelPrompt frontend

React + TypeScript + Vite + Tailwind v4 client for the AI Prompt Firewall.
See the top-level `README.md` (one directory up) for full setup instructions.

Quick start:

```bash
npm install
npm run dev
```
