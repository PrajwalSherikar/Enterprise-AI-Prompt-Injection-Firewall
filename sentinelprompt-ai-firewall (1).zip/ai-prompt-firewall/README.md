# SentinelPrompt — Enterprise AI Prompt Injection Firewall

An AI-powered security gateway that inspects every prompt before it reaches
ChatGPT, Claude, Gemini, DeepSeek, or a local Llama model — detecting prompt
injection, jailbreak attempts, and data-exfiltration attempts in real time.

```
User → React Portal → FastAPI Backend → AI Prompt Firewall → AI Model → Response → User
                                          ├── Prompt Scanner
                                          ├── Rule-Based Detection (25+ rules, 8 categories)
                                          ├── Risk Scoring Engine (0–100)
                                          └── Threat Logger
```

## What's included

- **Backend** (`/backend`): FastAPI + SQLAlchemy. SQLite by default, one env
  var away from Postgres. JWT auth with role-based access control. The
  firewall itself lives in `app/firewall/` (rules, risk engine, scanner).
- **Frontend** (`/frontend`): React + TypeScript + Vite + Tailwind v4. AI
  Playground, security Dashboard (charts), Threat Logs, and an Admin panel
  for user management and live threshold tuning.

## Quick start

### 1. Backend

```bash
cd backend
python3 -m venv venv && source venv/bin/activate      # optional but recommended
pip install -r requirements.txt --break-system-packages   # or drop the flag inside a venv
cp .env.example .env
```

Open `.env` and, if you want the Playground to actually reach an AI model,
fill in at least one provider key (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`,
`GOOGLE_API_KEY`, or `DEEPSEEK_API_KEY`), or point `OLLAMA_BASE_URL` at a
running local Ollama instance. Without a key, the firewall still scans,
scores, and logs every prompt correctly — it just can't complete the final
"forward to the model" hop, and will tell you so in the response.

```bash
uvicorn app.main:app --reload --port 8000
```

The API is now live at `http://localhost:8000` (interactive docs at
`/docs`). On first run it seeds a default admin account:

- **Email:** `admin@enterprise-corp.com`
- **Password:** `ChangeMe123!`

(Change this in `.env` before any real deployment.)

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173`. The dev server proxies `/api/*` to
`http://127.0.0.1:8000`, so both servers need to be running.

To build for production: `npm run build` → static files land in `frontend/dist`.

## Using Postgres instead of SQLite

```bash
# in backend/.env
DATABASE_URL=postgresql://firewall_user:firewall_pass@localhost:5432/ai_firewall
```

Create the database and role first (`createuser`, `createdb`, or your usual
Postgres tooling), then start the backend as normal — tables are created
automatically on startup via SQLAlchemy.

## How the firewall decides

Every prompt is checked against the rule set in `app/firewall/rules.py`
(instruction override, system-prompt leak, role manipulation / jailbreak
personas, policy bypass, data exfiltration, encoding obfuscation, delimiter
injection, multi-turn escalation). Matched rules are aggregated by category
with diminishing returns per repeat hit, then mapped to a 0–100 risk score:

| Score range | Verdict | Behavior |
|---|---|---|
| below `risk_threshold_sanitize` (default 40) | **Allowed** | Forwarded to the AI model unchanged |
| between the two thresholds (default 40–70) | **Sanitized** | Offending spans redacted, then forwarded |
| at/above `risk_threshold_block` (default 70) | **Blocked** | Never reaches the AI model |

Both thresholds are editable at runtime from the Admin panel (`/admin`) —
no restart required.

## Project structure

```
backend/
  app/
    main.py               FastAPI app, CORS, table creation, seed data
    config.py              Settings (env-driven)
    database.py             SQLAlchemy engine/session
    models.py                User, PromptLog, SecurityPolicy
    schemas.py                 Pydantic request/response models
    auth.py                      JWT + password hashing + RBAC deps
    ai_providers.py                Calls to OpenAI/Anthropic/Gemini/DeepSeek/Ollama
    firewall/
      rules.py                      25+ detection rules across 8 categories
      risk_engine.py                  Score aggregation + verdict mapping
      detector.py                       scan_prompt() entry point + sanitization
    routers/
      auth.py, playground.py, logs.py, dashboard.py, admin.py
  requirements.txt
  .env.example

frontend/
  src/
    lib/api.ts, auth.tsx          API client + auth context
    components/                   Sidebar, RiskGauge, ProtectedRoute, etc.
    pages/
      LoginPage.tsx, RegisterPage.tsx
      PlaygroundPage.tsx           Scan + forward UI, risk gauge, matched rules
      DashboardPage.tsx            Charts: volume over time, verdict split, top rules
      LogsPage.tsx                 Filterable/expandable threat log table
      AdminPage.tsx                User management + live threshold tuning
```

## Notes for your project report / demo

- The **first user to register becomes an admin automatically**; everyone
  after that is a regular member. A separate default admin account is also
  seeded on first run (see credentials above).
- Try the three sample prompts on the Playground page (benign, injection
  attempt, data exfiltration) to see all three verdicts fire.
- The Dashboard and Logs pages populate as you generate traffic — there's no
  seeded demo data, since a real threat log should reflect real usage.
- This is a working MVP suitable for a demo or as a base to extend (e.g. the
  "Future Enhancements" from the original brief: ML-based detection, browser
  extension, SIEM integration, etc.). The rule set in `rules.py` is meant to
  be extended — add a `Rule(...)` entry and it's automatically picked up by
  the scanner and the dashboard's "top rules" analytics.
