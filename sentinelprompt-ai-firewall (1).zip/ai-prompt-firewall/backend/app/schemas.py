from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, EmailStr, Field


# ---------- Auth ----------

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=8)


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: str
    name: str
    email: str
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------- Playground ----------

class PromptRequest(BaseModel):
    ai_model: str = Field(description="One of: openai, anthropic, gemini, ollama, deepseek")
    prompt: str = Field(min_length=1, max_length=8000)


class MatchedRule(BaseModel):
    rule_id: str
    category: str
    description: str
    weight: int


class PromptResponse(BaseModel):
    verdict: str
    risk_score: float
    matched_rules: List[MatchedRule]
    ai_response: Optional[str] = None
    message: str


# ---------- Logs ----------

class PromptLogOut(BaseModel):
    id: str
    user_id: str
    ai_model: str
    prompt_text: str
    verdict: str
    risk_score: float
    matched_rules: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Dashboard ----------

class DashboardStats(BaseModel):
    total_prompts: int
    total_blocked: int
    total_sanitized: int
    total_allowed: int
    block_rate: float
    top_rules: List[dict]
    prompts_over_time: List[dict]
    verdict_breakdown: List[dict]


# ---------- Admin ----------

class PolicyUpdate(BaseModel):
    key: str
    value: str


class PolicyOut(BaseModel):
    key: str
    value: str
    description: Optional[str]

    class Config:
        from_attributes = True
