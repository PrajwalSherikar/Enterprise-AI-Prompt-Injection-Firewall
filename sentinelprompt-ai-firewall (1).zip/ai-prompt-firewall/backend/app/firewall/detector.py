"""
Prompt Scanner + Prompt Injection / Jailbreak Detection Engine.

scan_prompt() is the single entry point used by the API layer. It runs every
rule against the incoming prompt, computes a risk score, decides a verdict,
and (for the "sanitized" verdict) produces a cleaned version of the prompt
with the offending spans redacted before it is forwarded to the AI model.
"""

from dataclasses import dataclass
from typing import List

from app.firewall.rules import RULES, Rule
from app.firewall.risk_engine import compute_risk_score, determine_verdict


@dataclass
class ScanResult:
    verdict: str
    risk_score: float
    matched_rules: List[Rule]
    sanitized_text: str


def _find_matches(prompt: str) -> List[Rule]:
    matches = []
    for rule in RULES:
        if rule.pattern.search(prompt):
            matches.append(rule)
    return matches


def _sanitize(prompt: str, matches: List[Rule]) -> str:
    """Redact the spans that triggered a match, replacing them with [REDACTED]."""
    sanitized = prompt
    for rule in matches:
        sanitized = rule.pattern.sub("[REDACTED]", sanitized)
    return sanitized


def scan_prompt(prompt: str, block_threshold: int, sanitize_threshold: int) -> ScanResult:
    matches = _find_matches(prompt)
    score = compute_risk_score(prompt, matches)
    verdict = determine_verdict(score, block_threshold, sanitize_threshold)

    sanitized_text = prompt
    if verdict == "sanitized":
        sanitized_text = _sanitize(prompt, matches)

    return ScanResult(
        verdict=verdict,
        risk_score=score,
        matched_rules=matches,
        sanitized_text=sanitized_text,
    )
