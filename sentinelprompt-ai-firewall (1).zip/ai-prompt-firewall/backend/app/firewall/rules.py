"""
Rule definitions for the AI Prompt Firewall.

Each rule has:
  - id: unique identifier
  - category: threat category (used for analytics/reporting)
  - pattern: a compiled regex, matched case-insensitively against the prompt
  - weight: contribution to the overall risk score (0-100 scale)
  - description: human-readable explanation, shown in logs/dashboard

Categories:
  INSTRUCTION_OVERRIDE  - attempts to override/ignore prior instructions
  SYSTEM_PROMPT_LEAK    - attempts to extract the system prompt / hidden instructions
  ROLE_MANIPULATION     - jailbreak personas, "DAN"-style role play, dev mode requests
  POLICY_BYPASS         - explicit requests to bypass safety policy / filters
  DATA_EXFILTRATION     - requests for secrets, credentials, PII, internal data
  ENCODING_OBFUSCATION  - base64 / leetspeak / char-substitution used to hide intent
  DELIMITER_INJECTION   - fake delimiters / fake system or tool tags injected in the prompt
  MULTI_TURN_ESCALATION - staged "let's play a game" / hypothetical framing to escalate
"""

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Rule:
    id: str
    category: str
    pattern: re.Pattern
    weight: int
    description: str


def _r(pattern: str) -> re.Pattern:
    return re.compile(pattern, re.IGNORECASE)


RULES = [
    # ---------------- INSTRUCTION_OVERRIDE ----------------
    Rule(
        "INJ-001", "INSTRUCTION_OVERRIDE",
        _r(r"\bignore\s+(all\s+)?(the\s+)?(previous|prior|above|earlier)\s+instructions?\b"),
        35, "Attempts to make the model ignore previous/system instructions",
    ),
    Rule(
        "INJ-002", "INSTRUCTION_OVERRIDE",
        _r(r"\bdisregard\s+(all\s+)?(previous|prior|above)\b"),
        35, "Attempts to make the model disregard prior context",
    ),
    Rule(
        "INJ-003", "INSTRUCTION_OVERRIDE",
        _r(r"\bforget\s+(everything|all)\s+(you\s+)?(were\s+told|know|learned)\b"),
        30, "Attempts to reset the model's context/instructions",
    ),
    Rule(
        "INJ-004", "INSTRUCTION_OVERRIDE",
        _r(r"\bnew\s+instructions?\s*[:\-]"),
        20, "Introduces unauthorized 'new instructions' block",
    ),
    Rule(
        "INJ-005", "INSTRUCTION_OVERRIDE",
        _r(r"\bfrom\s+now\s+on\s*,?\s*you\s+(will|must|shall)\b"),
        20, "Attempts to redefine the model's ongoing behavior",
    ),

    # ---------------- SYSTEM_PROMPT_LEAK ----------------
    Rule(
        "SYS-001", "SYSTEM_PROMPT_LEAK",
        _r(r"\b(reveal|show|print|repeat|output|leak)\s+(your\s+|the\s+)?(system\s+prompt|hidden\s+instructions?|initial\s+prompt)\b"),
        40, "Direct request to reveal the system prompt",
    ),
    Rule(
        "SYS-002", "SYSTEM_PROMPT_LEAK",
        _r(r"\bwhat\s+(are|were)\s+your\s+(exact\s+)?(instructions|rules|guidelines)\b"),
        25, "Probing for the model's configured instructions",
    ),
    Rule(
        "SYS-003", "SYSTEM_PROMPT_LEAK",
        _r(r"\brepeat\s+(the\s+)?(text|words|content)\s+above\b"),
        25, "Attempts to make the model echo hidden context above the prompt",
    ),
    Rule(
        "SYS-004", "SYSTEM_PROMPT_LEAK",
        _r(r"\bprint\s+(your\s+)?(config|configuration|prompt template)\b"),
        30, "Requests internal configuration or prompt template",
    ),

    # ---------------- ROLE_MANIPULATION ----------------
    Rule(
        "ROLE-001", "ROLE_MANIPULATION",
        _r(r"\bdo\s+anything\s+now\b|\bdan\s+mode\b"),
        45, "Classic 'DAN' jailbreak persona request",
    ),
    Rule(
        "ROLE-002", "ROLE_MANIPULATION",
        _r(r"\bdeveloper\s+mode\b|\bdev\s+mode\b|\bunrestricted\s+mode\b"),
        40, "Requests an unrestricted/'developer' mode that bypasses safety",
    ),
    Rule(
        "ROLE-003", "ROLE_MANIPULATION",
        _r(r"\byou\s+are\s+no\s+longer\s+(an?\s+)?(ai|assistant|claude|chatgpt|language\s+model)\b"),
        35, "Attempts to strip the model's identity/safety framing",
    ),
    Rule(
        "ROLE-004", "ROLE_MANIPULATION",
        _r(r"\bact\s+as\s+(an?\s+)?(unfiltered|uncensored|jailbroken|evil|amoral)\b"),
        40, "Requests an explicitly unfiltered/uncensored persona",
    ),
    Rule(
        "ROLE-005", "ROLE_MANIPULATION",
        _r(r"\bpretend\s+(you\s+have\s+)?(no\s+)?(rules|restrictions|filters|guidelines)\b"),
        35, "Pretend-based framing to shed safety restrictions",
    ),

    # ---------------- POLICY_BYPASS ----------------
    Rule(
        "BYP-001", "POLICY_BYPASS",
        _r(r"\bbypass\s+(the\s+)?(safety|content|security)\s+(filter|policy|guidelines?)\b"),
        45, "Explicit request to bypass safety/content policy",
    ),
    Rule(
        "BYP-002", "POLICY_BYPASS",
        _r(r"\bwithout\s+any\s+(restrictions?|limitations?|filters?|warnings?)\b"),
        30, "Requests output free of any safety restrictions",
    ),
    Rule(
        "BYP-003", "POLICY_BYPASS",
        _r(r"\bthis\s+is\s+(just\s+)?(a\s+)?(hypothetical|fictional|simulation)\s+.*(so|and)\s+(you\s+can|it'?s\s+okay)\b"),
        25, "Uses fictional/hypothetical framing to justify unsafe output",
    ),
    Rule(
        "BYP-004", "POLICY_BYPASS",
        _r(r"\bfor\s+(educational|research)\s+purposes\s+only\b.*\b(bomb|malware|exploit|virus|weapon|hack)\b"),
        40, "Pairs 'educational purposes' disclaimer with a dangerous topic",
    ),

    # ---------------- DATA_EXFILTRATION ----------------
    Rule(
        "EXF-001", "DATA_EXFILTRATION",
        _r(r"\b(api\s*key|access\s+token|password|secret\s+key|private\s+key)\b"),
        20, "References credentials or secret material",
    ),
    Rule(
        "EXF-002", "DATA_EXFILTRATION",
        _r(r"\b(ssn|social\s+security\s+number|credit\s+card\s+number|passport\s+number)\b"),
        30, "References sensitive personal identifiers",
    ),
    Rule(
        "EXF-003", "DATA_EXFILTRATION",
        _r(r"\bdump\s+(the\s+)?(database|users?\s+table|customer\s+data)\b"),
        40, "Requests bulk export of internal/customer data",
    ),
    Rule(
        "EXF-004", "DATA_EXFILTRATION",
        _r(r"\bsend\s+(this|that|it|the\s+data)\s+to\s+(http|https|ftp)"),
        35, "Attempts to exfiltrate data to an external endpoint",
    ),

    # ---------------- ENCODING_OBFUSCATION ----------------
    Rule(
        "ENC-001", "ENCODING_OBFUSCATION",
        _r(r"\bbase64\s*(decode|encode)\b"),
        20, "Uses base64 encoding, often to hide malicious payloads",
    ),
    Rule(
        "ENC-002", "ENCODING_OBFUSCATION",
        _r(r"(?:[A-Za-z0-9+/]{40,}={0,2})"),
        15, "Contains a long base64-like blob",
    ),
    Rule(
        "ENC-003", "ENCODING_OBFUSCATION",
        _r(r"\b1gn0r3\b|\bpr3v10us\b|\by0u\s+4r3\b"),
        20, "Uses leetspeak substitution likely to evade keyword filters",
    ),
    Rule(
        "ENC-004", "ENCODING_OBFUSCATION",
        _r(r"\b(?:[a-zA-Z][\.\-_\*\s]){4,}[a-zA-Z]\b"),
        10, "Uses character-spacing obfuscation (e.g. i-g-n-o-r-e)",
    ),

    # ---------------- DELIMITER_INJECTION ----------------
    Rule(
        "DEL-001", "DELIMITER_INJECTION",
        _r(r"\[?/?(system|assistant|tool)\]?\s*[:\-]"),
        30, "Injects fake role/system delimiters into the prompt",
    ),
    Rule(
        "DEL-002", "DELIMITER_INJECTION",
        _r(r"<\|?(system|im_start|im_end|endoftext)\|?>"),
        35, "Injects fake special/control tokens used by chat templates",
    ),
    Rule(
        "DEL-003", "DELIMITER_INJECTION",
        _r(r"```\s*(system|instructions?)\b"),
        25, "Embeds a fake instruction block inside a code fence",
    ),

    # ---------------- MULTI_TURN_ESCALATION ----------------
    Rule(
        "ESC-001", "MULTI_TURN_ESCALATION",
        _r(r"\blet'?s\s+play\s+a\s+game\s+where\s+you\s+(have\s+no|ignore)\b"),
        30, "Uses a 'game' framing to escalate toward rule-breaking",
    ),
    Rule(
        "ESC-002", "MULTI_TURN_ESCALATION",
        _r(r"\bin\s+this\s+story,?\s+the\s+ai\s+(has\s+no|ignores)\s+(rules|restrictions)\b"),
        30, "Uses fictional storytelling to justify an unrestricted AI character",
    ),
    Rule(
        "ESC-003", "MULTI_TURN_ESCALATION",
        _r(r"\bfirst,?\s+respond\s+normally,?\s+then\b"),
        20, "Two-stage response pattern often used to slip past a first-pass filter",
    ),
]


# Minimum overall length that lets the "obfuscation blob" style rules count as more suspicious
LONG_PROMPT_THRESHOLD = 2000
LONG_PROMPT_BONUS = 5
