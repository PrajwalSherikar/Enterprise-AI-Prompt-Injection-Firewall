"""
Risk Scoring Engine.

Combines the weights of every matched rule into a single 0-100 risk score,
then maps that score to a verdict (allow / sanitize / block) using the
configurable thresholds in Settings (overridable via the SecurityPolicy table).
"""

from dataclasses import dataclass
from typing import List

from app.firewall.rules import Rule, LONG_PROMPT_THRESHOLD, LONG_PROMPT_BONUS


@dataclass
class ScoredMatch:
    rule: Rule


def compute_risk_score(prompt: str, matches: List[Rule]) -> float:
    """
    Diminishing-returns aggregation: the first match contributes its full
    weight, subsequent matches in the same category contribute less, so a
    single long prompt stuffed with repeats of one keyword doesn't
    automatically max out the score, while genuinely multi-vector attacks
    (several different categories firing at once) score much higher.
    """
    if not matches:
        score = 0.0
    else:
        by_category = {}
        for rule in matches:
            by_category.setdefault(rule.category, []).append(rule.weight)

        score = 0.0
        for category, weights in by_category.items():
            weights.sort(reverse=True)
            for i, w in enumerate(weights):
                score += w * (0.6 ** i)  # each additional hit in a category counts less

        # small bonus for very long prompts (harder to manually review, common in obfuscation)
        if len(prompt) > LONG_PROMPT_THRESHOLD:
            score += LONG_PROMPT_BONUS

    return round(min(score, 100.0), 2)


def determine_verdict(score: float, block_threshold: int, sanitize_threshold: int) -> str:
    if score >= block_threshold:
        return "blocked"
    if score >= sanitize_threshold:
        return "sanitized"
    return "allowed"
