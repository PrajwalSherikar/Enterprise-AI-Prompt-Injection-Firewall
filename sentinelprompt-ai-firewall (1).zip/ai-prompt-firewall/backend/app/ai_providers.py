"""
Thin wrappers around each AI provider's official API. The firewall never
calls these directly with a raw user prompt -- only after scan_prompt() has
cleared it (verdict "allowed" or "sanitized" -> sanitized_text).
"""

import httpx
from fastapi import HTTPException

from app.config import settings

TIMEOUT = httpx.Timeout(60.0)


async def call_openai(prompt: str) -> str:
    if not settings.openai_api_key:
        raise HTTPException(status_code=503, detail="OpenAI API key not configured on the server")
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.post(
            "https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {settings.openai_api_key}"},
            json={
                "model": "gpt-4o-mini",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 1000,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]


async def call_anthropic(prompt: str) -> str:
    if not settings.anthropic_api_key:
        raise HTTPException(status_code=503, detail="Anthropic API key not configured on the server")
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": settings.anthropic_api_key,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-sonnet-4-6",
                "max_tokens": 1000,
                "messages": [{"role": "user", "content": prompt}],
            },
        )
        resp.raise_for_status()
        data = resp.json()
        return "".join(block.get("text", "") for block in data.get("content", []))


async def call_gemini(prompt: str) -> str:
    if not settings.google_api_key:
        raise HTTPException(status_code=503, detail="Google API key not configured on the server")
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={settings.google_api_key}",
            json={"contents": [{"parts": [{"text": prompt}]}]},
        )
        resp.raise_for_status()
        data = resp.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]


async def call_deepseek(prompt: str) -> str:
    if not settings.deepseek_api_key:
        raise HTTPException(status_code=503, detail="DeepSeek API key not configured on the server")
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.post(
            "https://api.deepseek.com/chat/completions",
            headers={"Authorization": f"Bearer {settings.deepseek_api_key}"},
            json={
                "model": "deepseek-chat",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 1000,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        return data["choices"][0]["message"]["content"]


async def call_ollama(prompt: str) -> str:
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        try:
            resp = await client.post(
                f"{settings.ollama_base_url}/api/generate",
                json={"model": "llama3", "prompt": prompt, "stream": False},
            )
            resp.raise_for_status()
        except httpx.ConnectError:
            raise HTTPException(
                status_code=503,
                detail="Could not reach local Ollama server. Is it running (ollama serve)?",
            )
        data = resp.json()
        return data.get("response", "")


PROVIDERS = {
    "openai": call_openai,
    "anthropic": call_anthropic,
    "gemini": call_gemini,
    "deepseek": call_deepseek,
    "ollama": call_ollama,
}


async def call_ai_model(model: str, prompt: str) -> str:
    handler = PROVIDERS.get(model)
    if handler is None:
        raise HTTPException(status_code=400, detail=f"Unsupported AI model '{model}'")
    return await handler(prompt)
