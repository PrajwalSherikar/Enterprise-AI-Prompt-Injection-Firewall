from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine, SessionLocal
from app.config import settings
from app.models import User, RoleEnum, SecurityPolicy
from app.auth import hash_password
from app.routers import auth, playground, logs, dashboard, admin

Base.metadata.create_all(bind=engine)


def seed_defaults():
    db = SessionLocal()
    try:
        if db.query(User).count() == 0:
            admin_user = User(
                name="System Administrator",
                email=settings.default_admin_email,
                hashed_password=hash_password(settings.default_admin_password),
                role=RoleEnum.admin,
            )
            db.add(admin_user)

        defaults = {
            "risk_threshold_block": (str(settings.risk_threshold_block), "Score at/above which a prompt is blocked"),
            "risk_threshold_sanitize": (str(settings.risk_threshold_sanitize), "Score at/above which a prompt is sanitized rather than allowed"),
        }
        for key, (value, description) in defaults.items():
            if not db.query(SecurityPolicy).filter(SecurityPolicy.key == key).first():
                db.add(SecurityPolicy(key=key, value=value, description=description))

        db.commit()
    finally:
        db.close()


seed_defaults()

app = FastAPI(
    title="Enterprise AI Prompt Injection Firewall",
    description="AI-powered security gateway for real-time prompt injection and jailbreak detection.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin, "http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(playground.router)
app.include_router(logs.router)
app.include_router(dashboard.router)
app.include_router(admin.router)


@app.get("/api/health")
def health_check():
    return {"status": "ok", "service": "ai-prompt-firewall-backend"}
