import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    Column, String, Integer, Float, DateTime, Boolean, Text, ForeignKey, Enum
)
from sqlalchemy.orm import relationship

from app.database import Base


def gen_uuid():
    return str(uuid.uuid4())


class RoleEnum(str, enum.Enum):
    admin = "admin"
    user = "user"


class VerdictEnum(str, enum.Enum):
    allowed = "allowed"
    sanitized = "sanitized"
    blocked = "blocked"


class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=gen_uuid)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False, index=True)
    hashed_password = Column(String, nullable=False)
    role = Column(Enum(RoleEnum), default=RoleEnum.user, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    prompt_logs = relationship("PromptLog", back_populates="user")


class PromptLog(Base):
    """Every prompt submitted through the AI Playground, safe or not."""
    __tablename__ = "prompt_logs"

    id = Column(String, primary_key=True, default=gen_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    ai_model = Column(String, nullable=False)
    prompt_text = Column(Text, nullable=False)
    sanitized_text = Column(Text, nullable=True)
    ai_response = Column(Text, nullable=True)

    verdict = Column(Enum(VerdictEnum), nullable=False)
    risk_score = Column(Float, nullable=False)
    matched_rules = Column(Text, nullable=True)  # JSON-encoded list of rule ids/reasons

    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="prompt_logs")


class SecurityPolicy(Base):
    """Configurable thresholds and toggles, editable from the admin panel."""
    __tablename__ = "security_policy"

    id = Column(String, primary_key=True, default=gen_uuid)
    key = Column(String, unique=True, nullable=False)
    value = Column(String, nullable=False)
    description = Column(String, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
