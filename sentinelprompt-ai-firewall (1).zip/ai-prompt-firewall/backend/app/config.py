from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "sqlite:///./ai_firewall.db"

    jwt_secret_key: str = "insecure-dev-secret-change-me"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 120

    default_admin_email: str = "admin@enterprise-corp.com"
    default_admin_password: str = "ChangeMe123!"

    risk_threshold_block: int = 70
    risk_threshold_sanitize: int = 40

    openai_api_key: str = ""
    anthropic_api_key: str = ""
    google_api_key: str = ""
    deepseek_api_key: str = ""
    ollama_base_url: str = "http://localhost:11434"

    frontend_origin: str = "http://localhost:5173"


settings = Settings()
