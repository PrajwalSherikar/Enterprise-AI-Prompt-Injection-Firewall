import json
from collections import Counter, defaultdict
from datetime import datetime

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, PromptLog, RoleEnum, VerdictEnum
from app.schemas import DashboardStats
from app.auth import get_current_user

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/stats", response_model=DashboardStats)
def get_stats(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    query = db.query(PromptLog)
    if current_user.role != RoleEnum.admin:
        query = query.filter(PromptLog.user_id == current_user.id)

    logs = query.all()

    total = len(logs)
    blocked = sum(1 for l in logs if l.verdict == VerdictEnum.blocked)
    sanitized = sum(1 for l in logs if l.verdict == VerdictEnum.sanitized)
    allowed = sum(1 for l in logs if l.verdict == VerdictEnum.allowed)
    block_rate = round((blocked / total) * 100, 2) if total else 0.0

    rule_counter = Counter()
    for l in logs:
        if l.matched_rules:
            try:
                for r in json.loads(l.matched_rules):
                    rule_counter[f"{r['rule_id']} - {r['description']}"] += 1
            except (json.JSONDecodeError, KeyError):
                continue
    top_rules = [{"rule": k, "count": v} for k, v in rule_counter.most_common(8)]

    by_day = defaultdict(lambda: {"allowed": 0, "sanitized": 0, "blocked": 0})
    for l in logs:
        day = l.created_at.strftime("%Y-%m-%d") if isinstance(l.created_at, datetime) else str(l.created_at)
        by_day[day][l.verdict.value] += 1
    prompts_over_time = [
        {"date": day, **counts} for day, counts in sorted(by_day.items())
    ]

    verdict_breakdown = [
        {"verdict": "allowed", "count": allowed},
        {"verdict": "sanitized", "count": sanitized},
        {"verdict": "blocked", "count": blocked},
    ]

    return DashboardStats(
        total_prompts=total,
        total_blocked=blocked,
        total_sanitized=sanitized,
        total_allowed=allowed,
        block_rate=block_rate,
        top_rules=top_rules,
        prompts_over_time=prompts_over_time,
        verdict_breakdown=verdict_breakdown,
    )
