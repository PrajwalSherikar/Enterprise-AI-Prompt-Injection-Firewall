import json

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, PromptLog, VerdictEnum, SecurityPolicy
from app.schemas import PromptRequest, PromptResponse, MatchedRule
from app.auth import get_current_user
from app.firewall.detector import scan_prompt
from app.ai_providers import call_ai_model
from app.config import settings

router = APIRouter(prefix="/api/playground", tags=["playground"])


def _get_thresholds(db: Session):
    block = db.query(SecurityPolicy).filter(SecurityPolicy.key == "risk_threshold_block").first()
    sanitize = db.query(SecurityPolicy).filter(SecurityPolicy.key == "risk_threshold_sanitize").first()
    block_val = int(block.value) if block else settings.risk_threshold_block
    sanitize_val = int(sanitize.value) if sanitize else settings.risk_threshold_sanitize
    return block_val, sanitize_val


@router.post("/scan", response_model=PromptResponse)
async def scan_and_forward(
    payload: PromptRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    block_threshold, sanitize_threshold = _get_thresholds(db)

    result = scan_prompt(payload.prompt, block_threshold, sanitize_threshold)

    matched_rules_json = json.dumps([
        {"rule_id": r.id, "category": r.category, "description": r.description, "weight": r.weight}
        for r in result.matched_rules
    ])

    ai_response = None
    message = ""

    if result.verdict == "blocked":
        message = "This prompt was blocked by the AI Firewall due to a high risk score. The request was not sent to the AI model."
    else:
        try:
            ai_response = await call_ai_model(payload.ai_model, result.sanitized_text)
            message = (
                "Prompt passed the firewall and was forwarded to the AI model."
                if result.verdict == "allowed"
                else "Prompt was sanitized (suspicious segments redacted) before being forwarded to the AI model."
            )
        except Exception as exc:
            message = f"Prompt passed the firewall, but the AI provider call failed: {exc}"

    log = PromptLog(
        user_id=current_user.id,
        ai_model=payload.ai_model,
        prompt_text=payload.prompt,
        sanitized_text=result.sanitized_text if result.verdict == "sanitized" else None,
        ai_response=ai_response,
        verdict=VerdictEnum(result.verdict),
        risk_score=result.risk_score,
        matched_rules=matched_rules_json,
    )
    db.add(log)
    db.commit()

    return PromptResponse(
        verdict=result.verdict,
        risk_score=result.risk_score,
        matched_rules=[
            MatchedRule(rule_id=r.id, category=r.category, description=r.description, weight=r.weight)
            for r in result.matched_rules
        ],
        ai_response=ai_response,
        message=message,
    )
