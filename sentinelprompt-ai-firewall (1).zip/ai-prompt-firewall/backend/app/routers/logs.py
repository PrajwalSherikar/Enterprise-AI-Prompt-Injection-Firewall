from typing import Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, PromptLog, RoleEnum
from app.schemas import PromptLogOut
from app.auth import get_current_user

router = APIRouter(prefix="/api/logs", tags=["logs"])


@router.get("/", response_model=list[PromptLogOut])
def get_logs(
    verdict: Optional[str] = Query(None, description="Filter by allowed / sanitized / blocked"),
    limit: int = Query(100, le=500),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    query = db.query(PromptLog)

    # Regular users only see their own history; admins see everyone's
    if current_user.role != RoleEnum.admin:
        query = query.filter(PromptLog.user_id == current_user.id)

    if verdict:
        query = query.filter(PromptLog.verdict == verdict)

    logs = query.order_by(PromptLog.created_at.desc()).limit(limit).all()
    return logs
