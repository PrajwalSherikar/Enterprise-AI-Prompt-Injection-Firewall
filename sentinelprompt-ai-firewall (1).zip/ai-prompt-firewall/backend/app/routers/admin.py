from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import User, SecurityPolicy, RoleEnum
from app.schemas import UserOut, PolicyUpdate, PolicyOut
from app.auth import require_admin

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.get("/users", response_model=list[UserOut])
def list_users(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return db.query(User).order_by(User.created_at.desc()).all()


@router.patch("/users/{user_id}/toggle-active", response_model=UserOut)
def toggle_user_active(user_id: str, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.id == admin.id:
        raise HTTPException(status_code=400, detail="You cannot deactivate your own account")
    user.is_active = not user.is_active
    db.commit()
    db.refresh(user)
    return user


@router.patch("/users/{user_id}/role", response_model=UserOut)
def change_user_role(user_id: str, role: RoleEnum, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.role = role
    db.commit()
    db.refresh(user)
    return user


@router.get("/policies", response_model=list[PolicyOut])
def list_policies(admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    return db.query(SecurityPolicy).all()


@router.put("/policies", response_model=PolicyOut)
def update_policy(payload: PolicyUpdate, admin: User = Depends(require_admin), db: Session = Depends(get_db)):
    policy = db.query(SecurityPolicy).filter(SecurityPolicy.key == payload.key).first()
    if not policy:
        raise HTTPException(status_code=404, detail=f"Unknown policy key '{payload.key}'")
    policy.value = payload.value
    db.commit()
    db.refresh(policy)
    return policy
